﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticaGrupal_MaquinaVending
{
    internal abstract class Producto
    {
        //Atributos de los productos

        public int TipoProducto { get; set; }

        public string NombreProducto { get; set; }

        public int UnidadesProducto { get; set; }

        public double PrecioProducto { get; set; }

        public string DescripcionProducto { get; set; }
        
        public int Id { get; set; }



        public Producto(int tipoProducto, string nombreProducto, int unidadesProducto, double precioProducto, string descripcionProducto, int id)
        {
            TipoProducto = tipoProducto;
            NombreProducto= nombreProducto;
            UnidadesProducto = unidadesProducto;
            PrecioProducto = precioProducto;
            DescripcionProducto= descripcionProducto;
            Id = id;
        }

        

    }
}
