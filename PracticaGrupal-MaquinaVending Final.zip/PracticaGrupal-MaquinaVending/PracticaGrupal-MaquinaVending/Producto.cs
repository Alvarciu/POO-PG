﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticaGrupal_MaquinaVending
{
    internal abstract class Producto
    {
        //Atributos de los productos

        public int TipoProducto { get; set; }

        public string NombreProducto { get; set; }

        public int UnidadesProducto { get; set; }

        public double PrecioProducto { get; set; }

        public string DescripcionProducto { get; set; }
        
        public int Id { get; set; }



        public Producto(int id, int tipoProducto, string nombreProducto, int unidadesProducto, double precioProducto, string descripcionProducto)
        {
            TipoProducto = tipoProducto;
            NombreProducto= nombreProducto;
            UnidadesProducto = unidadesProducto;
            PrecioProducto = precioProducto;
            DescripcionProducto= descripcionProducto;
            Id = id;
        }

        public void InfoProducto()
        {
            Console.WriteLine($"\nID: {Id}\n Nombre: {NombreProducto}\n Unidades restantes: {UnidadesProducto}\n Precio: {PrecioProducto}");
        }
        public virtual void MostrarDetalles()
        { 
            Console.WriteLine($"\nID: {Id}\n Nombre: {NombreProducto}\n Unidades restantes: {UnidadesProducto}\n Precio: {PrecioProducto}\n Descripcion: {DescripcionProducto}");
        }
  
        

    }
}
