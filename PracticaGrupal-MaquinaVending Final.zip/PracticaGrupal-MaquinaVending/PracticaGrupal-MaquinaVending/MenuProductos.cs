﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace PracticaGrupal_MaquinaVending
{
    internal class MenuProductos
    {
        private List<Producto> listaProductos { get; set; }

        public MenuProductos(List<Producto> LP)
        {
            this.listaProductos = LP;
        }
        public void MenuCliente()
        {
            int opcion4 = 0;

            Console.Clear();
            Console.WriteLine("╔═══════════════════════════════════════════╗");
            Console.WriteLine("║           UFV Vending Machine             ║");
            Console.WriteLine("╠═══════════════════════════════════════════╣");
            Console.WriteLine("║ 1. Comprar Productos                      ║");
            Console.WriteLine("║ 2. Ver informacion de los productos       ║");
            Console.WriteLine("╚═══════════════════════════════════════════╝");
            Console.WriteLine("Por favor elija una opcion: ");

            opcion4 = int.Parse(Console.ReadLine());

            switch (opcion4)
            {
                case 1:
                    Console.Clear();
                    CompraProductos();
                    break;

                case 2:
                    MostrarInformacionProducto();
                    break;

                default:
                    Console.Clear();
                    break;
            }
        }

        public void MenuAdministrador()
        {
            int opcion6 = 0;

            do
            {
                Console.Clear();
                Console.WriteLine("╔═══════════════════════════════════════════╗");
                Console.WriteLine("║          UFV Vending Machine              ║");
                Console.WriteLine("╠═══════════════════════════════════════════╣");
                Console.WriteLine("║ 1. Comprar Productos                      ║");
                Console.WriteLine("║ 2. Ver informacion de los productos       ║");
                Console.WriteLine("║ 3. Cargar productos de forma manual       ║");
                Console.WriteLine("║ 4. Cargar productos de forma automatica   ║");
                Console.WriteLine("║ 5. Salir                                  ║");
                Console.WriteLine("╚═══════════════════════════════════════════╝");
                Console.WriteLine("Por favor elija una opcion: \n\t");

                opcion6 = int.Parse(Console.ReadLine());

                switch (opcion6)
                {
                    case 1:
                        Console.Clear();
                        CompraProductos();
                        break;

                    case 2:
                        MostrarInformacionProducto();
                        break;

                    case 3:
                        CargaManual();
                        break;

                    case 4:
                        CargaPorFichero();
                        break;
                    case 5:
                        break;

                    default:
                        Console.Clear();
                        break;
                }
            } while (opcion6 != 5);

        }
        public void CompraProductos()
        {
            List<Producto> productosSeleccionados = new List<Producto>();

            // Mostrar los productos disponibles
            Console.WriteLine("Productos disponibles:");
            foreach (Producto producto in listaProductos)
            {
                producto.InfoProducto();
            }

            while (true)
            {
                Console.WriteLine("\nPor favor, introduzca el ID del producto que desee comprar (0 para pagar y salir): ");
                int id = int.Parse(Console.ReadLine());

                if (id == 0)
                {
                    break; // Salir del bucle si el usuario ingresa 0 para pagar y salir
                }

                // Buscar el producto por ID
                Producto productoSeleccionado = listaProductos.FirstOrDefault(p => p.Id == id);

                if (productoSeleccionado == null)
                {
                    Console.WriteLine("El ID de producto ingresado no es válido.");
                }
                else
                {
                    productosSeleccionados.Add(productoSeleccionado);
                    Console.WriteLine($"Producto '{productoSeleccionado.NombreProducto}' agregado al carrito.");
                }
            }

            // Realizar el pago para los productos seleccionados
            foreach (Producto producto in productosSeleccionados)
            {
                MetodoPago(productosSeleccionados);
            }
        }


        public void MetodoPago(List<Producto> productosSeleccionados)
        {
            Console.Clear();

            double totalAPagar = 0;

            foreach (Producto producto in productosSeleccionados)
            {
                totalAPagar += producto.PrecioProducto;
            }

            int opcion5 = 0;
            Console.WriteLine("Por favor, seleccione el método de pago:");
            Console.WriteLine("1. Pago en efectivo");
            Console.WriteLine("2. Pago con tarjeta");

            opcion5 = int.Parse(Console.ReadLine());
            switch (opcion5)
            {
                case 1:
                    Console.Clear();
                    Console.WriteLine("Ha elegido la opción de pago en efectivo!!!");

                    double monedaInsertada = 0;

                    Console.WriteLine($"\nEl total a pagar es: {totalAPagar}");

                    while (totalAPagar > monedaInsertada)
                    {
                        Console.Write($"\nInserte una moneda ({totalAPagar - monedaInsertada} restante): ");
                        double moneda = double.Parse(Console.ReadLine());

                        monedaInsertada += moneda;
                    }

                    // Verificar si se debe devolver cambio
                    if (monedaInsertada > totalAPagar)
                    {
                        double cambio = monedaInsertada - totalAPagar;

                        Console.WriteLine($"\nTotal introducido: {monedaInsertada}");
                        Console.WriteLine($"Cambio a devolver: {cambio}");

                        Console.Write("\n¿Desea recibir el cambio? (S/N): ");
                        string respuesta = Console.ReadLine();

                        if (respuesta.ToUpper() == "S")
                        {
                            Console.WriteLine($"\nCambio entregado: {cambio}. ¡Gracias por su compra!");
                            foreach (Producto producto in productosSeleccionados)
                            {
                                producto.UnidadesProducto = producto.UnidadesProducto - 1;
                            }
                        }
                        else
                        {
                            Console.WriteLine($"\nHa cancelado la transacción. ¡Gracias por visitar la máquina expendedora!");
                        }
                    }
                    else
                    {
                        Console.WriteLine("\nPago completado. ¡Gracias por su compra!");
                        
                    }
                    break;

                case 2:
                    Console.Clear();
                    Console.WriteLine("Ha elegido el pago con tarjeta!!!\n");

                    Console.WriteLine("\nIntroduce los datos de la tarjeta:");
                    string numeroTarjeta;
                    do
                    {
                        Console.Write("\nNúmero de tarjeta (16 dígitos): ");
                        numeroTarjeta = Console.ReadLine();
                    } while (numeroTarjeta.Length != 16 || !ValidacionTarjeta(numeroTarjeta));

                    string codigoSeguridad;
                    do
                    {
                        Console.Write("\nCódigo de seguridad (3 dígitos): ");
                        codigoSeguridad = Console.ReadLine();
                    } while (codigoSeguridad.Length != 3 || !ValidacionTarjeta(codigoSeguridad));

                    string fechaCaducidad;
                    do
                    {
                        Console.Write("\nFecha de caducidad (mm/aa): ");
                        fechaCaducidad = Console.ReadLine();
                    } while (!ValidacionFechaCaducidad(fechaCaducidad));

                    Console.WriteLine("\nPago con tarjeta completado. ¡Gracias por su compra!");
                    foreach (Producto producto in productosSeleccionados)
                    {
                        producto.UnidadesProducto = producto.UnidadesProducto - 1;
                    }
                    Console.ReadKey();
                    break;


                default:
                    Console.WriteLine("Opción no válida. Por favor, seleccione una opción válida.");
                    break;
            }
        }



        static bool ValidacionTarjeta(string numeroIntroducido)
        {
            foreach (char nI in numeroIntroducido)
            {
                if (!char.IsDigit(nI))
                {
                    return false;
                }
            }
            return true;
        }

        static bool ValidacionFechaCaducidad(string fecha)
        {
            if (fecha.Length != 5) return false;  // Comprueba la longitud correcta

            string[] partes = fecha.Split('/');
            if (partes.Length != 2) return false;  // Comprueba que tenga un separador

            if (!int.TryParse(partes[0], out int mes) || !int.TryParse(partes[1], out int año))
                return false;  // Comprueba que ambos componentes son numéricos

            if (mes < 1 || mes > 12) return false;  // Comprueba que el mes es válido

            // Añadir aquí cualquier otra lógica necesaria

            return true;  // Retorna verdadero si todas las validaciones pasan
        }



        public void CargaManual()
        {
            Console.Clear();
            if (listaProductos.Count < 12)
            {
                int id;
                int tipoProducto;
                string nombreProducto;
                int unidadesProducto;
                double precioProducto;
                string descripcionProducto;
                string materiales;
                string peso;
                string informacionNutricional;
                string bateria;
                string preCarga;
                Console.WriteLine("Que tipo de producto deseas cargar: ");
                Console.WriteLine("1. Materiales Preciosos:");
                Console.WriteLine("2. Productos Alimenticios: ");
                Console.WriteLine("3. Productos Electronicos: ");
                tipoProducto = int.Parse(Console.ReadLine());
                Console.WriteLine("Introduzca el ID: ");
                id = int.Parse(Console.ReadLine());
                Console.WriteLine("Introduzca el Nombre del Producto: ");
                nombreProducto = Console.ReadLine();
                Console.WriteLine("Introduzca el precio del producto: ");
                precioProducto = double.Parse(Console.ReadLine());
                Console.WriteLine("Introduzca las Unidades disponibles del producto:");
                unidadesProducto = int.Parse(Console.ReadLine());
                Console.WriteLine("Introduzca una Descripcion para el producto");
                descripcionProducto = Console.ReadLine();

                switch (tipoProducto)
                {
                    case 1:
                        Console.WriteLine("Introduce el tipo de material del producto: ");
                        materiales = Console.ReadLine();
                        Console.WriteLine("Introduce el peso del producto: ");
                        peso = Console.ReadLine();
                        MaterialesPreciosos materialesPreciosos = new MaterialesPreciosos(id, tipoProducto, nombreProducto, unidadesProducto, precioProducto, descripcionProducto, materiales, peso);
                        listaProductos.Add(materialesPreciosos);
                        break;

                    case 2:
                        Console.WriteLine("Introduzca su valor nutricional: ");
                        informacionNutricional = Console.ReadLine();
                        ProductoAlimenticio productoAlimenticio = new ProductoAlimenticio(id, tipoProducto, nombreProducto, unidadesProducto, precioProducto, descripcionProducto, informacionNutricional);
                        listaProductos.Add(productoAlimenticio);

                        break;

                    case 3:
                        Console.WriteLine("El producto tiene bateria (si/no): ");
                        bateria = Console.ReadLine();
                        Console.WriteLine("El producto viene precargado (si/no): ");
                        preCarga = Console.ReadLine();
                        ProductosElectronicos productosElectronicos = new ProductosElectronicos(id, tipoProducto, nombreProducto, unidadesProducto, precioProducto, descripcionProducto, bateria, preCarga);
                        listaProductos.Add(productosElectronicos);
                        break;

                    default:
                        Console.WriteLine("El valor introducido es incorrecto!!!");
                        break;

                }
            }
            else
            {
                Console.Clear();
                Console.WriteLine("No pueden cargar más productos porque la maquina se encuntra llena");
                Console.ReadKey();
            }
        }


        public void MostrarInformacionProducto()
        {
            foreach (Producto producto in listaProductos)
            {
                producto.InfoProducto();
            }
            Console.WriteLine("\n¿Que producto desea ver completo?");
            int id = int.Parse(Console.ReadLine());

            foreach(Producto producto in listaProductos)
            {
                if (producto.Id == id)
                {
                    Console.Clear();
                    producto.MostrarDetalles();
                }
            }
            Console.ReadKey();
        }


        public void CargaPorFichero()
        {
            Console.Clear();
            Console.WriteLine("Porfavor introduce el nombre del fichero que desea cargar: ");
            string fichero = Console.ReadLine();
            if (File.Exists(fichero))
            {
                StreamReader sr = new StreamReader(fichero);
                string linea;

                while ((linea = sr.ReadLine()) != null)
                {
                    string[] datos = linea.Split(';');

                    if (listaProductos.Count < 12)
                    {
                        int id = int.Parse(datos[0]);
                        int tipoProducto = int.Parse(datos[1]);
                        string nombreProducto = datos[2];
                        int unidadesProducto = int.Parse(datos[3]);
                        double precioProducto = double.Parse(datos[4]);
                        string descripcionProducto = datos[5];
                        string materiales = datos[6];
                        string peso = datos[7];
                        string informacionNutricional = datos[8];
                        string bateria = datos[9];
                        string preCarga = datos[10];

                        if (datos[1] == "1")
                        {
                            MaterialesPreciosos materialesPreciosos = new MaterialesPreciosos(id, tipoProducto, nombreProducto, unidadesProducto, precioProducto, descripcionProducto, materiales, peso);
                            listaProductos.Add(materialesPreciosos);
                        }

                        if (datos[1] == "2")
                        {
                            ProductoAlimenticio productoAlimenticio = new ProductoAlimenticio(id, tipoProducto, nombreProducto, unidadesProducto, precioProducto, descripcionProducto, informacionNutricional);
                            listaProductos.Add(productoAlimenticio);
                        }

                        if (datos[1] == "3")
                        {
                            ProductosElectronicos productosElectronicos = new ProductosElectronicos(id, tipoProducto, nombreProducto, unidadesProducto, precioProducto, descripcionProducto, bateria, preCarga);
                            listaProductos.Add(productosElectronicos);
                        }
                        Console.WriteLine("Se he cargado el producto " + nombreProducto + " de forma correcta!!!");
                    }
                    else
                    {
                        Console.WriteLine("No puede cargar el producto " + datos[2] + " porque la maquina se encuntra llena");
                    }
                }
                
                    
                Console.ReadKey();

                sr.Close();
            }
            else
            {
                File.Create("ProductosVending.csv").Close();
            }


        }

    }
}
