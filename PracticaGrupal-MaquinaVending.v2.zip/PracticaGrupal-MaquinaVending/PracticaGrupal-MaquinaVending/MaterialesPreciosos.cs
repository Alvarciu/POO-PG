﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticaGrupal_MaquinaVending
{
    internal class MaterialesPreciosos : Producto 
    {
        public string Materiales { get; set; }
        public int Peso { get; set; }



        public MaterialesPreciosos(string materiales, int tipoProducto, string nombreProducto, int unidadesProducto, double precioProducto, string descripcionProducto, int peso) : base(tipoProducto, nombreProducto, unidadesProducto, precioProducto, descripcionProducto)
        {
            Materiales = materiales;
            Peso = peso;
        }


    }
}
