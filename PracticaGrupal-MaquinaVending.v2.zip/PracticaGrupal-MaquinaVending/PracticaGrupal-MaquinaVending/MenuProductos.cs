﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticaGrupal_MaquinaVending
{
    internal class MenuProductos
    {
        public void MenuProducto()
        {
            int opcion2 = 0;

            Console.Clear();
            Console.WriteLine("Bienvenido a nuestra maquina de vending!!!");
            Console.Clear();
            Console.WriteLine("Seleccione el tipo de producto que desee: ");
            Console.WriteLine("1. Materiales Preciosos:");
            Console.WriteLine("2. Productos Alimenticios: ");
            Console.WriteLine("3. Productos Electronicos: ");
            Console.WriteLine("Porfavor elija una opcion: \n\t");
            try
            {
                opcion2 = int.Parse(Console.ReadLine());

                switch (opcion2)
                {
                    case 1:
                        Console.WriteLine("Ha eligido Materiales Preciosos");
                        string filePath = "ProductosVending.csv";

                        // Leer el archivo CSV línea por línea
                        using (StreamReader reader = new StreamReader(filePath))
                        {
                            while (!reader.EndOfStream)
                            {
                                string line = reader.ReadLine();
                                // Separar los campos utilizando la coma como delimitador
                                string[] fields = line.Split(';');


                                string nombreProducto = fields[0];
                                int tipoProducto = int.Parse(fields[1]);
                                int unidadesProducto = int.Parse(fields[2]);
                                double precioProducto = double.Parse(fields[3]);

                                if (tipoProducto == 1)
                                {
                                    // Imprimir los datos que deseas
                                    Console.WriteLine($"Nombre: {nombreProducto}, tipo: {tipoProducto}, unidades: {unidadesProducto}, precio: {precioProducto}");
                                }
                            }
                        }
                        break;
                    case 2:
                        Console.WriteLine("Has elegido Productos Alimenticios");
                        filePath = "ProductosVending.csv";

                        // Leer el archivo CSV línea por línea
                        using (StreamReader reader = new StreamReader(filePath))
                        {
                            while (!reader.EndOfStream)
                            {
                                string line = reader.ReadLine();
                                // Separar los campos utilizando la coma como delimitador
                                string[] fields = line.Split(';');


                                string nombreProducto = fields[0];
                                int tipoProducto = int.Parse(fields[1]);
                                int unidadesProducto = int.Parse(fields[2]);
                                double precioProducto = double.Parse(fields[3]);

                                if (tipoProducto == 2)
                                {
                                    // Imprimir los datos que deseas
                                    Console.WriteLine($"Nombre: {nombreProducto}, tipo: {tipoProducto}, unidades: {unidadesProducto}, precio: {precioProducto}");
                                }
                            }
                        }
                        break;

                    case 3:
                        Console.WriteLine("Ha elegido Productos Electronicos");
                        filePath = "ProductosVending.csv";

                        // Leer el archivo CSV línea por línea
                        using (StreamReader reader = new StreamReader(filePath))
                        {
                            while (!reader.EndOfStream)
                            {
                                string line = reader.ReadLine();
                                // Separar los campos utilizando la coma como delimitador
                                string[] fields = line.Split(';');


                                string nombreProducto = fields[0];
                                int tipoProducto = int.Parse(fields[1]);
                                int unidadesProducto = int.Parse(fields[2]);
                                double precioProducto = double.Parse(fields[3]);

                                if (tipoProducto == 3)
                                {
                                    // Imprimir los datos que deseas
                                    Console.WriteLine($"Nombre: {nombreProducto}, tipo: {tipoProducto}, unidades: {unidadesProducto}, precio: {precioProducto}");
                                }
                            }
                        }
                        break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("El valor introducido es erroneo!!!" + ex.Message);
            }

        }

        public void MetodoPago()
        {
            Console.Clear();

            int opcion5 = 0;
            Console.WriteLine("Porfavor seleccione el metodo de pago:");
            Console.WriteLine("1. Pago en efectivo");
            Console.WriteLine("2. Pago con tarjeta");

            opcion5 = int.Parse(Console.ReadLine());
            switch (opcion5)
            {
                case 1:
                    Console.Clear();
                    Console.WriteLine("Ha elegido pagar en efectivo, por favor realiza el pago introduciendo monedas de una en una ");
                    //falta hacer el codigo de la resta del valor de la compra
                    Console.Clear();
                    Console.WriteLine("La maquina solo acepta monedas de 1€ o 2€");
                    int eleccionMoneda = 0;
                    Console.WriteLine("Introduzca el numero uno si quiere pagar con monedas de 1€ o 2 si desea pagar con monedas de 2€");

                    eleccionMoneda = int.Parse(Console.ReadLine());

                    switch (eleccionMoneda)
                    {
                        case 1:
                            Console.Clear();
                            Console.WriteLine("Introduzca las monedas de 1€ necesarias");
                            break;

                        case 2:
                            Console.Clear();
                            Console.WriteLine("Introduzca las monedas de 2€ necesarias");
                            break;
                    }
                    break;

                case 2:
                    Console.Clear();
                    Console.WriteLine("Ha elegido pagar con tarjeta, porfavor introduzca los datos de su tarjeta!!");
                    Console.WriteLine("Porfavor introduzca el numero de su tarjeta: ");
                    Console.WriteLine("Porfavor introduzca la fecha de caducidad de su tarjeta: ");
                    Console.WriteLine("Porfavor introduzca el CVC de su tarjeta: ");

                    Console.WriteLine("El precio total de su compra es: %f");

                    char respuestaCompra;
                    Console.WriteLine("Desea continuar la compra (s/n): ");
                    respuestaCompra = Convert.ToChar(Console.ReadLine());


                    if (respuestaCompra == 's')
                    {
                        Console.WriteLine("Se ha realizado la compra correctamente");
                    }
                    else if (respuestaCompra == 'n')
                    {
                        Console.WriteLine("Su compra se ha cancelado");
                    }
                    else
                    {
                        Console.WriteLine("La opcion que has introducido es incorrecta, vuelve a introducir una opcion correcta");
                    }

                    break;
            }
        }
    }
}
