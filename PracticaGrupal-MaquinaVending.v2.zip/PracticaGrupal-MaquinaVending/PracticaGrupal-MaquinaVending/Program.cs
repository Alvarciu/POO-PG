﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticaGrupal_MaquinaVending
{
    internal class Program
    {
        static string adminUsuario = "admin";
        static string adminContraseña = "admin";

        static void Main(string[] args)
        {
            Console.WriteLine("Bienvenido a la máquina de vending, ¿desea iniciar sesión como administrador (1) o como usuario (2)?.");
            Console.WriteLine("1. Iniciar sesión como administrador");
            Console.WriteLine("2. Iniciar sesión como usuario");
            Console.WriteLine("3. Salir");

            string opcion1 = Console.ReadLine();

            switch (opcion1)
            {
                case "1":
                    LoginAdministrador();
                    break;
                case "2":
                    LoginUsuario();
                    break;
                case "3":
                    Console.WriteLine("---Saliendo—--");
                    break;
                default:
                    Console.WriteLine("Opción no válida. Por favor, seleccione una opción válida.");
                    break;
            }
        }

        static void LoginAdministrador()
        {
            Console.Write("Ingrese el nombre de usuario: ");
            string usuario = Console.ReadLine();
            Console.Write("Ingrese la contraseña: ");
            string contraseñas = Console.ReadLine();

            if (usuario == adminUsuario && contraseñas == adminContraseña)
            {
                Console.WriteLine("Se ha iniciado sesión como administrador");
            }
            else
            {
                Console.WriteLine("Nombre de usuario o contraseña incorrectos.");
            }
        }

        static void LoginUsuario()
        {
            Console.WriteLine("Ha iniciado sesión como usuario");
            MenuProductos menu = new MenuProductos();
        }


    }
}
