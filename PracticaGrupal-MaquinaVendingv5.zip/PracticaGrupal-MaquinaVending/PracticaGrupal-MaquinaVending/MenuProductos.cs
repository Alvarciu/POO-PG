﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticaGrupal_MaquinaVending
{
    internal class MenuProductos
    {

        public static void MenuCliente()
        {
            int opcion4 = 0;

            Console.Clear();
            Console.WriteLine("Bienvenido a nuestra maquina vending!!!");
            Console.WriteLine("---------------------------------------");
            Console.WriteLine("1. Comprar Productos");
            Console.WriteLine("2. Ver informacion de los productos");
            Console.WriteLine("Por favor elija una opcion: ");

            opcion4 = int.Parse(Console.ReadLine());

            switch(opcion4)
            {
                case 1:
                    Console.Clear();
                    CompraProductos();
                    break;

                case 2:
                    InformacionProducto();
                    break;

                default: 
                    Console.Clear();
                    break; 
            }


        }

        public static void MenuAdministrador()
        {
            int opcion6 = 0;

            Console.Clear();
            Console.WriteLine("Bienvenido a nuestra maquina vending!!!");
            Console.WriteLine("---------------------------------------");
            Console.WriteLine("1. Comprar Productos");
            Console.WriteLine("2. Ver informacion de los productos");
            Console.WriteLine("3. Cargar productos de forma manual");
            Console.WriteLine("4. Cargar productos de forma automatica");
            Console.WriteLine("Porfavor elija una opcion: \n\t");

            opcion6 = int.Parse(Console.ReadLine());

            switch (opcion6)
            {
                case 1:
                    Console.Clear();
                    CompraProductos();
                    break;

                case 2:
                    InformacionProducto();
                    break;

                case 3:
                    //Codigo para cargar productos de forma manual
                    break;

                case 4:
                    //Codigo para cargar productos de forma automatica
                    break;

                    default:
                        Console.Clear();
                        break;
            }


        }
        public static void CompraProductos()
        {
            Console.WriteLine("Porfavor introduzca el ID de los productos que desee comprar: ");
            Console.ReadLine();
        }

        public static void InformacionProducto()
        {
            int opcion2 = 0;

            Console.Clear();
            Console.WriteLine("Seleccione el tipo de producto que desee: ");
            Console.WriteLine("1. Materiales Preciosos:");
            Console.WriteLine("2. Productos Alimenticios: ");
            Console.WriteLine("3. Productos Electronicos: ");
            Console.WriteLine("Porfavor elija una opcion: \n");
            try
            {
                opcion2 = int.Parse(Console.ReadLine());

                switch (opcion2)
                {
                    case 1:
                        Console.WriteLine("Ha eligido Materiales Preciosos");
                        string filePath = @"ProductosVending2.csv";
                        try
                        {
                            // Leer el archivo CSV línea por línea
                            using (StreamReader reader = new StreamReader(filePath))
                            {
                                while (!reader.EndOfStream)
                                {
                                    string line = reader.ReadLine();
                                    // Separar los campos utilizando el punto y coma como delimitador
                                    string[] fields = line.Split(';');

                                    // Verificar que la línea tenga el formato esperado
                                    if (fields.Length >= 4)
                                    {
                                        string NombreProducto = fields[0];
                                        int TipoProducto = int.Parse(fields[1]);
                                        //int UnidadesProducto = int.Parse(fields[2]);
                                        //double PrecioProducto = double.Parse(fields[3]);

                                        if (TipoProducto == 1)
                                        {
                                            // Imprimir los datos que deseas
                                            Console.WriteLine($"Nombre: {NombreProducto}, tipo: {TipoProducto} º");
                                            Console.ReadKey();
                                        }
                                    }
                                    else
                                    {
                                        // Mostrar un mensaje de error si la línea no tiene el formato esperado
                                        Console.WriteLine("Error: El formato de la línea no es válido.");
                                        Console.ReadKey();
                                    }
                                    Console.ReadKey();
                                }
                                Console.ReadKey();
                            }
                        }
                        catch (Exception ex)
                        {
                            // Capturar excepciones y mostrar información de error
                            Console.WriteLine($"Error al leer el archivo: {ex.Message}");
                            Console.ReadKey();
                        }
                        break;

                    case 2:
                        Console.WriteLine("Has elegido Productos Alimenticios");
                        filePath = @"ProductosVending.csv";

                        // Leer el archivo CSV línea por línea
                        using (StreamReader reader = new StreamReader(filePath))
                        {
                            while (!reader.EndOfStream)
                            {
                                string line = reader.ReadLine();
                                // Separar los campos utilizando la coma como delimitador
                                string[] fields = line.Split(';');


                                string nombreProducto = fields[0];
                                int tipoProducto = int.Parse(fields[1]);
                                int unidadesProducto = int.Parse(fields[2]);
                                double precioProducto = double.Parse(fields[3]);

                                if (tipoProducto == 2)
                                {
                                    // Imprimir los datos que deseas
                                    Console.WriteLine($"Nombre: {nombreProducto}, tipo: {tipoProducto}, unidades: {unidadesProducto}, precio: {precioProducto}");
                                }
                            }
                        }
                        break;

                    case 3:
                        Console.WriteLine("Ha elegido Productos Electronicos");
                        filePath = @"ProductosVending.csv";

                        // Leer el archivo CSV línea por línea
                        using (StreamReader reader = new StreamReader(filePath))
                        {
                            while (!reader.EndOfStream)
                            {
                                string line = reader.ReadLine();
                                // Separar los campos utilizando la coma como delimitador
                                string[] fields = line.Split(';');


                                string nombreProducto = fields[0];
                                int tipoProducto = int.Parse(fields[1]);
                                int unidadesProducto = int.Parse(fields[2]);
                                double precioProducto = double.Parse(fields[3]);

                                if (tipoProducto == 3)
                                {
                                    // Imprimir los datos que deseas
                                    Console.WriteLine($"Nombre: {nombreProducto}, tipo: {tipoProducto}, unidades: {unidadesProducto}, precio: {precioProducto}");
                                }
                            }
                        }
                        break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("El valor introducido es erroneo!!!" + ex.Message);
            }
        }

        public void MetodoPago()
        {
            Console.Clear();

            int opcion5 = 0;
            Console.WriteLine("Porfavor seleccione el metodo de pago:");
            Console.WriteLine("1. Pago en efectivo");
            Console.WriteLine("2. Pago con tarjeta");

            opcion5 = int.Parse(Console.ReadLine());
            switch (opcion5)
            {
                case 1:
                    Console.Clear();
                    Console.WriteLine("Ha elegido la opcion de pago en efectivo!!!");
                    double monedaInsertada = 0;
                    double total = 0 ;

                    Console.WriteLine($"\nEl total a pagar es: {total}");

                    while (total > monedaInsertada)
                    {
                        Console.Write($"\nInserte una moneda ({total - monedaInsertada} restante): ");
                        double moneda = double.Parse(Console.ReadLine());

                        monedaInsertada += moneda;
                    }

                    // Verificar si se debe devolver cambio
                    if (monedaInsertada > total)
                    {
                        double cambio = monedaInsertada - total;

                        Console.WriteLine($"\nTotal introducido: {monedaInsertada}");
                        Console.WriteLine($"Cambio a devolver: {cambio}");

                        Console.Write("\n¿Desea recibir el cambio? (S/N): ");
                        string respuesta = Console.ReadLine();

                        if (respuesta.ToUpper() == "S")
                        {
                            Console.WriteLine($"\nCambio entregado: {cambio}. ¡Gracias por su compra!");
                            Console.ReadKey();
                        }
                        else
                        {
                            Console.WriteLine($"\nHa cancelado la transacción. ¡Gracias por visitar la máquina expendedora!");

                        }
                    }
                    else
                    {
                        Console.WriteLine("\nPago completado. ¡Gracias por su compra!");
                        Console.ReadKey();
                    }
                    break;

                case 2:
                    Console.Clear();
                    Console.WriteLine("Ha elegido el pago con tarjeta!!!\n");
                    Console.WriteLine("\nIntroduce los datos de la tarjeta:");

                    string numeroTarjeta;
                    do
                    {
                        Console.Write("\nNúmero de tarjeta (20 dígitos): ");
                        numeroTarjeta = Console.ReadLine();
                    } while (numeroTarjeta.Length != 20 || !ValidacionTarjeta(numeroTarjeta));

                    Console.Write("\nFecha de caducidad (MM/YY): ");
                    string fechaCaducidad = Console.ReadLine();

                    string codigoSeguridad;
                    do
                    {
                        Console.Write("\nCódigo de seguridad (3 dígitos): ");
                        codigoSeguridad = Console.ReadLine();
                    } while (codigoSeguridad.Length != 3 || !ValidacionTarjeta(codigoSeguridad));

                    Console.WriteLine("\nPago con tarjeta completado. ¡Gracias por su compra!");
                    Console.ReadKey();

                    break;

            }
        }

        static bool ValidacionTarjeta(string numeroIntroducido)
        {
            foreach (char nI in numeroIntroducido)
            {
                if (!char.IsDigit(nI))
                {
                    return false;
                }
            }
            return true;
        }

    }
}
