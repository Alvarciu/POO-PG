﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticaGrupal_MaquinaVending
{
    internal class ProductoAlimenticio : Producto
    {
        //Atributos de ProductoAlimenticio

        public int InformacionNutricional { get; set; }


        public ProductoAlimenticio(int informacionNutricional, int tipoProducto, string nombreProducto, int unidadesProducto, double precioProducto, string descripcionProducto, int id):base (tipoProducto,nombreProducto,unidadesProducto, precioProducto, descripcionProducto, id)
        {
            InformacionNutricional = informacionNutricional;
        }
    }
}
