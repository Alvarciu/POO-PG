﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticaGrupal_MaquinaVending
{
    internal abstract class Producto
    {
        //Atributos de los productos

        public int TipoProducto { get; set; }

        public string NombreProducto { get; set; }

        public int UnidadesProducto { get; set; }

        public double PrecioProducto { get; set; }

        public string DescripcionProducto { get; set; } 


        public Producto(int tipoProducto, string nombreProducto, int unidadesProducto, double precioProducto, string descripcionProducto)
        {
            TipoProducto = tipoProducto;
            NombreProducto= nombreProducto;
            UnidadesProducto = unidadesProducto;
            PrecioProducto = precioProducto;
            DescripcionProducto= descripcionProducto;
        }

        public void Menu()
        {
            int opcion = 0;
            Console.Clear();
            Console.WriteLine("Bienvenido a nuestra maquina de vending!!!");
            Console.Clear();
            Console.WriteLine("Seleccione el tipo de producto que desee: ");
            Console.WriteLine("1. Materiales Preciosos:");
            Console.WriteLine("2. Productos Alimenticios: ");
            Console.WriteLine("3. Productos Electronicos: ");
            Console.WriteLine("Porfavor elija una opcion: \n\t");
            try
            {
                opcion = int.Parse(Console.ReadLine());

                switch (opcion)
                {
                    case 1:
                        Console.WriteLine("Ha eligido Materiales Preciosos");
                        break;

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("El valor introducido es erroneo!!!" + ex.Message);
            }

        }



        public void MetodoPago()
        {
           Console.Clear();

           int opcion = 0;
           Console.WriteLine("Porfavor seleccione el metodo de pago:");
            Console.WriteLine("1. Pago en efectivo");
            Console.WriteLine("2. Pago con tarjeta");

            opcion = int.Parse(Console.ReadLine());
            switch (opcion)
            {
                case 1:
                    Console.Clear();
                    Console.WriteLine("Ha elegido pagar en efectivo, por favor realiza el pago introduciendo monedas de una en una ");
                    //falta hacer el codigo de la resta del valor de la compra
                    Console.Clear();
                    Console.WriteLine("La maquina solo acepta monedas de 1€ o 2€");
                    int eleccionMoneda = 0;
                    Console.WriteLine("Introduzca el numero uno si quiere pagar con monedas de 1€ o 2 si desea pagar con monedas de 2€");

                    eleccionMoneda = int.Parse(Console.ReadLine());

                    switch (eleccionMoneda)
                    {
                        case 1: 
                            Console.Clear();
                            Console.WriteLine("Introduzca las monedas de 1€ necesarias");
                            break;

                        case 2: 
                            Console.Clear();
                            Console.WriteLine("Introduzca las monedas de 2€ necesarias");
                            break;
                    }
                    break;

                case 2:
                    Console.Clear();
                    Console.WriteLine("Ha elegido pagar con tarjeta, porfavor introduzca los datos de su tarjeta!!");
                    Console.WriteLine("Porfavor introduzca el numero de su tarjeta: ");
                    Console.WriteLine("Porfavor introduzca la fecha de caducidad de su tarjeta: ");
                    Console.WriteLine("Porfavor introduzca el CVC de su tarjeta: ");

                    Console.WriteLine("El precio total de su compra es: %f", &precioTotalCompra);

                    char respuestaCompra;
                    Console.WriteLine("Desea continuar la compra (s/n): ");
                    respuestaCompra = Convert.ToChar(Console.ReadLine());


                    if(respuestaCompra.toUpper == 's')
                    {
                        Console.WriteLine("Se ha realizado la compra correctamente");
                    }
                    else if (respuestaCompra == 'n')
                    {
                        Console.WriteLine("Su compra se ha cancelado");
                    }
                    else
                    {
                        Console.WriteLine("La opcion que has introducido es incorrecta, vuelve a introducir una opcion correcta");
                    }

                    break; 
            }
        }

    }
}
