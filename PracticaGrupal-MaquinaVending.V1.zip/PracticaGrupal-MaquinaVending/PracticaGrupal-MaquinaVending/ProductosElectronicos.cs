﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticaGrupal_MaquinaVending
{
    internal class ProductosElectronicos : Producto

    {
        public bool Bateria { get; set; }

        public bool PreCarga { get; set; }


        public ProductosElectronicos(bool bateria, bool preCarga, int tipoProducto, string nombreProducto, int unidadesProducto, double precioProducto, string descripcionProducto) : base(tipoProducto, nombreProducto, unidadesProducto, precioProducto, descripcionProducto)
        { 
            Bateria= bateria;
            PreCarga= preCarga;
        }

    }
}
