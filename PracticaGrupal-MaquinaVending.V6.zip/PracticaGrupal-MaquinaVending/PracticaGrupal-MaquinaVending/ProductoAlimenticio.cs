﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticaGrupal_MaquinaVending
{
    internal class ProductoAlimenticio : Producto
    {
        //Atributos de ProductoAlimenticio

        public string InformacionNutricional { get; set; }


        public ProductoAlimenticio(int id, int tipoProducto, string nombreProducto, int unidadesProducto, double precioProducto, string descripcionProducto, string informacionNutricional) :base (id, tipoProducto, nombreProducto, unidadesProducto, precioProducto, descripcionProducto)
        {
            InformacionNutricional = informacionNutricional;
        }

        public override void MostrarDetalles()
        {
            base.MostrarDetalles();
            Console.WriteLine($"Informcion Nutricional: {InformacionNutricional}\n");
        }
    }
}
