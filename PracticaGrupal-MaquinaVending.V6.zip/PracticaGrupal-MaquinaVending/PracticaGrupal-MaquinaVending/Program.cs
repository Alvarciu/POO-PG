﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticaGrupal_MaquinaVending
{
    public class Program
    {
        static List<Producto> ListProducto;
        static string adminUsuario = "admin";
        static string adminContraseña = "admin";
        static void Main(string[] args)
        {
            ListProducto= new List<Producto>();
            Console.WriteLine("╔═══════════════════════════════════════════╗");
            Console.WriteLine("║          UFV Vending Machine              ║");
            Console.WriteLine("╠═══════════════════════════════════════════╣");
            Console.WriteLine("║ 1. Iniciar sesión como administrador      ║");
            Console.WriteLine("║ 2. Iniciar sesión como usuario            ║");
            Console.WriteLine("║ 3. Salir                                  ║");
            Console.WriteLine("╚═══════════════════════════════════════════╝");

            string opcion1 = Console.ReadLine();
            switch (opcion1)
            {
                case "1":
                    LoginAdministrador();
                    break;
                case "2":
                    LoginUsuario();
                    break;
                case "3":
                    Console.Clear();
                    Console.WriteLine("---Saliendo—--");
                    Console.ReadKey();
                    break;
                default:
                    Console.WriteLine("Opción no válida. Por favor, seleccione una opción válida.");
                    break;
            }
        }

        static  void LoginAdministrador()
        {
            Console.Clear();
            MenuProductos menu = new MenuProductos(ListProducto);
            Console.Write("Ingrese el nombre de usuario: ");
            string usuario = Console.ReadLine().ToLower();
            Console.Write("Ingrese la contraseña: ");
            string contraseñas = Console.ReadLine().ToLower();
            if (usuario == adminUsuario && contraseñas == adminContraseña)
            {
                Console.Clear() ;
                Console.WriteLine("╔═══════════════════════════════════════════╗");
                Console.WriteLine("║          UFV Vending Machine              ║");
                Console.WriteLine("╠═══════════════════════════════════════════╣");
                Console.WriteLine("║                                           ║");
                Console.WriteLine("║ Se ha iniciado sesion como administrador  ║");
                Console.WriteLine("║                                           ║");
                Console.WriteLine("╚═══════════════════════════════════════════╝");
                Console.ReadKey();
                menu.MenuAdministrador();
            }
            else
            {
                Console.WriteLine("╔═══════════════════════════════════════════╗");
                Console.WriteLine("║          UFV Vending Machine              ║");
                Console.WriteLine("╠═══════════════════════════════════════════╣");
                Console.WriteLine("║                                           ║");
                Console.WriteLine("║Nombre de usuario o contraseña incorrectos ║");
                Console.WriteLine("║                                           ║");
                Console.WriteLine("╚═══════════════════════════════════════════╝");
                Console.ReadKey();
            }
        }

        static void LoginUsuario()
        {
            Console.Clear();
            MenuProductos menu = new MenuProductos(ListProducto);
            Console.WriteLine("╔═══════════════════════════════════════════╗");
            Console.WriteLine("║          UFV Vending Machine              ║");
            Console.WriteLine("╠═══════════════════════════════════════════╣");
            Console.WriteLine("║                                           ║");
            Console.WriteLine("║     Ha iniciado sesión como usuario       ║");
            Console.WriteLine("║                                           ║");
            Console.WriteLine("╚═══════════════════════════════════════════╝");
            Console.ReadKey();
            menu.MenuCliente();
        }


    }
}
