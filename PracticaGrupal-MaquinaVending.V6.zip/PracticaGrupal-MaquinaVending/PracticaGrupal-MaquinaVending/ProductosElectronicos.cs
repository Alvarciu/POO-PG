﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticaGrupal_MaquinaVending
{
    internal class ProductosElectronicos : Producto

    {
        public string Bateria { get; set; }

        public string PreCarga { get; set; }


        public ProductosElectronicos(int id, int tipoProducto, string nombreProducto, int unidadesProducto, double precioProducto, string descripcionProducto, string bateria, string preCarga) : base(id, tipoProducto, nombreProducto, unidadesProducto, precioProducto, descripcionProducto)
        { 
            Bateria= bateria;
            PreCarga= preCarga;
        }

        public override void MostrarDetalles()
        {
            base.MostrarDetalles();
            Console.WriteLine($"Bateria: {Bateria}\n Precarga: {PreCarga}\n");
        }

    }
}
